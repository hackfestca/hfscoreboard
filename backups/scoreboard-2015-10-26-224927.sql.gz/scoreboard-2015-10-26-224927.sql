--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = scoreboard, pg_catalog;

--
-- Data for Name: bmitemcategory; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY bmitemcategory (id, name, displayname, description, ts) FROM stdin;
1	admin	Admin	This item was created by an admin and can be considered safe.	2015-10-26 21:38:19.853207
2	player	Player	This item was uploaded by a player.	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: bmitemreview; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY bmitemreview (id, rating, comments, ts) FROM stdin;
\.


--
-- Data for Name: bmitemstatus; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY bmitemstatus (id, code, name, description, ts) FROM stdin;
1	1	For Sale	This item is for sale.	2015-10-26 21:38:19.853207
2	2	Sold	This item is sold and is not available anymore (qty = 0).	2015-10-26 21:38:19.853207
3	3	For approval	This item was submitted by a player and needs approval.	2015-10-26 21:38:19.853207
4	4	Refused by admin	This item was put on black market by a player and was refused by an admin.	2015-10-26 21:38:19.853207
5	5	Removed from game	This item was removed during the CTF.	2015-10-26 21:38:19.853207
6	6	Ready to publish	This status will tell the bmUpdater to publish the item on the scoreboard front-end.	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: wallet; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY wallet (id, publicid, name, description, amount, ts) FROM stdin;
2	7c88ee0b57a9513c67f3a38dd0339516b9704f1747648988858866e38e75c1b2	HF Loto	Default wallet used to manage loto.	0.00	2015-10-26 21:38:19.853207
3	5a966c0ae8b8ba56ad507a62ba60f30c887d76dcf3699c0c0757b0122f8d0605	_TMIH_	Wallet of team: _TMIH_	1000.00	2015-10-26 21:38:20.393856
4	b172f09ccb488ef36b2dd061349b91117dc922920bf70e0b282ec4d6a9dddfe7	return ENEEDGIN;	Wallet of team: return ENEEDGIN;	1000.00	2015-10-26 21:38:20.393856
5	076ee04291d59a74a809fff2a047e76ed675c464c61ec8a27735b5c0cb07745d	DCIETS	Wallet of team: DCIETS	1000.00	2015-10-26 21:38:20.393856
6	a2f3db62af2a0b191ddf701b11e609536de5fdd4fb775f1dc5c262058e1f8598	Hack ULaval	Wallet of team: Hack ULaval	1000.00	2015-10-26 21:38:20.393856
7	a4fabd8502e9700479eafddde839b1fd66eb3333242ddb1a9267ececba68e3e2	Shellbleedoodleshock	Wallet of team: Shellbleedoodleshock	1000.00	2015-10-26 21:38:20.393856
8	73c5b350b1093144690b6f2ef65d087683fd16b63d9b168c8273672616a77428	Eliteroot	Wallet of team: Eliteroot	1000.00	2015-10-26 21:38:20.393856
9	d9888649b297443a2def94f978bac5e7ef2aa7a2e69452b7bcc73b7f6cf83e9a	EMTA XIDLESYC GODS !	Wallet of team: EMTA XIDLESYC GODS !	1000.00	2015-10-26 21:38:20.393856
10	34d92afe53b1a6caccd2df22ec34ef058d337959b41a0fed82debe393d9b5263	Flaggots	Wallet of team: Flaggots	1000.00	2015-10-26 21:38:20.393856
11	7e666fcfa9e421b9394fb4553a92dc879fbd9de69c2a49b4b21987cedb09dde0	GLO in the dark	Wallet of team: GLO in the dark	1000.00	2015-10-26 21:38:20.393856
12	e1605e4b360e3ed8d20c0f5128f497de8ea69bcb27f86e91c8d916f65d38db69	Good Work IOIextreme	Wallet of team: Good Work IOIextreme	1000.00	2015-10-26 21:38:20.393856
13	3556de457a52c20c88c8f2888b39ffd9114cd8dc60168d7d35588b15854fa4fe	crackmayorsecurity	Wallet of team: crackmayorsecurity	1000.00	2015-10-26 21:38:20.393856
14	bfc1c8941dc9c8a39d1ef7074ea977cc27c09db917b3f3128536383bacaa87ef	In the middle man 	Wallet of team: In the middle man 	1000.00	2015-10-26 21:38:20.393856
15	2c6f157b66e4d9e8a043ccc56c38b6c2db8996184c83c69ab36c2cac8c4cb25f	l33tb33s	Wallet of team: l33tb33s	1000.00	2015-10-26 21:38:20.393856
16	6e69e7d7bf48b26d5e7e7859f79d79c0334c66995d34c57e250763cb8456c4b9	Packet Drop	Wallet of team: Packet Drop	1000.00	2015-10-26 21:38:20.393856
17	41e5ac832f802f1f1311eb6b1405cff22803d0f3cc9cf447b566d1834a53b0f9	Ping Master	Wallet of team: Ping Master	1000.00	2015-10-26 21:38:20.393856
18	997a2872590e2bcc93fa1b6b1a01f7d59cbdc768f5edbcf175bd72be7bd5f519	PolyHack	Wallet of team: PolyHack	1000.00	2015-10-26 21:38:20.393856
19	154a2483a5f1d8687aa181892e5b403cee80e6b03d366b56f370b90297127c1b	Quick Overflow 	Wallet of team: Quick Overflow 	1000.00	2015-10-26 21:38:20.393856
20	a52394c8784eee984d757e41a80d291a34b646ad283d97599e54baab59b4394f	Relentless Penguin Uprising	Wallet of team: Relentless Penguin Uprising	1000.00	2015-10-26 21:38:20.393856
21	382da5ef72a3785d18a914b0d3733a1a236ac1c0a28a1d64b43d55f70f060202	@dminPr0tect n friends	Wallet of team: @dminPr0tect n friends	1000.00	2015-10-26 21:38:20.393856
22	7616599d92dce8ad89fba1b91af909bc84f3051c630ad13261360d1695e5ba3b	Sea and Tea	Wallet of team: Sea and Tea	1000.00	2015-10-26 21:38:20.393856
23	2d142b9a0fb9b8b647b8ecd68a74374f7c7461ca15fcbe535fe9c5aab1a83c14	Shell investigator	Wallet of team: Shell investigator	1000.00	2015-10-26 21:38:20.393856
24	6415c144f93e04acc88afe37a9f685a52a9a59ba9ce07760bfc838e8b8d68490	BonziBuddy	Wallet of team: BonziBuddy	1000.00	2015-10-26 21:38:20.393856
25	f605f6261c011742cd6e34cba869aea95ceef6216994bf1aa071616e119b9b2f	thinker^or^die	Wallet of team: thinker^or^die	1000.00	2015-10-26 21:38:20.393856
26	e0b8bdfd73009c514265f77331d516319cb4138e40bdfedc1a6cdab3ae8af78a	Unicorn as a service	Wallet of team: Unicorn as a service	1000.00	2015-10-26 21:38:20.393856
27	6b418ab053be69146f9ed707f5618b1d9c97369bc34a2f66aecd1f9263f53b71	Freethinker1	Wallet of team: Freethinker1	1000.00	2015-10-26 21:38:20.393856
28	a135e8f5808c04e88139c596f27a2ec093044bbc7677377b762eef94f899bb88	Freethinker2	Wallet of team: Freethinker2	1000.00	2015-10-26 21:38:20.393856
29	3c081686f756b71e3e4e5f06c2d146bad224b07835f6d3122d7eb73ac66ebfa6	usedoils	Wallet of team: usedoils	1000.00	2015-10-26 21:38:20.393856
30	8d91f3b5f193364e38b9515075fd3140f64f4cedce8dbeda60ae22df4916e288	team28	Wallet of team: team28	1000.00	2015-10-26 21:38:20.393856
31	d1c04eebc36bd432c59719715d44f92bfa65e4a3748ff65f68e138a6ebe709fa	team29	Wallet of team: team29	1000.00	2015-10-26 21:38:20.393856
32	1f1d1eabb661b118df5010ad97a68b4bef09cc3e3cbed7bd93b774fd4afee75c	team30	Wallet of team: team30	1000.00	2015-10-26 21:38:20.393856
33	eda700652c7223e0ff77be23def7f082ddc3e08cb53a71bdc1456d4d5fe8f197	team31	Wallet of team: team31	1000.00	2015-10-26 21:38:20.393856
34	ee3d931bdba667d1c7869051270af94b90139325243e7a173c82a9959abeaf75	team32	Wallet of team: team32	1000.00	2015-10-26 21:38:20.393856
35	3b0ea42d7ccd07c9c2256ac1093c98de5954d22d6926a349d0528a5200b9e075	team33	Wallet of team: team33	1000.00	2015-10-26 21:38:20.393856
36	ae2d5972fbeab444b6f57925533c803d3de1c78a6331133b16707d233492ba8b	team34	Wallet of team: team34	1000.00	2015-10-26 21:38:20.393856
37	08379d4f58cda96e7633f7aa6f2e8a5ff927272db1357acdc6f28b0ea0205b7f	team35	Wallet of team: team35	1000.00	2015-10-26 21:38:20.393856
38	ee24df36962e6897853153108c039b64335c886ee69a16fce2c188059e4e5875	team36	Wallet of team: team36	1000.00	2015-10-26 21:38:20.393856
39	1aff03ad062f577d0b167d95d33da32326c8f3eaefbad1fb3e20495c931605c3	team37	Wallet of team: team37	1000.00	2015-10-26 21:38:20.393856
40	a6470327d71ea5306f79059dfe6596f7ce3eeb1cdf7cb8ed3473502538bf55be	team38	Wallet of team: team38	1000.00	2015-10-26 21:38:20.393856
41	b080bba0e221a01814f721399f435d1d7ab20ef320fa9ac07888781044ce2a92	team39	Wallet of team: team39	1000.00	2015-10-26 21:38:20.393856
42	86d410256bcf78015d5e9bf74a07b4242962b2d93c20301637f57487dda029bf	team40	Wallet of team: team40	1000.00	2015-10-26 21:38:20.393856
43	9a17442ed987f2f280f7b1c69d78516f729b7083efc9e6523c6adf82c10131ab	team41	Wallet of team: team41	1000.00	2015-10-26 21:38:20.393856
44	5e3661518ef74e824c23d3605ff3b9098e3bad2ca62684fa1c88bac2b8cc7e7d	team42	Wallet of team: team42	1000.00	2015-10-26 21:38:20.393856
45	e6c311825017bf4913f11f42530e9ee4dfeddc5584afa8d79947f9917d58a9f9	team43	Wallet of team: team43	1000.00	2015-10-26 21:38:20.393856
46	8d8e947561f4095456ed3ddc398f94bfa1d55cbba96da37848f48d38a7e59f21	team44	Wallet of team: team44	1000.00	2015-10-26 21:38:20.393856
47	3475ae04aea8cda8741506461faa126bca30bdf29f1526611cf14ad5ea0a78d7	team45	Wallet of team: team45	1000.00	2015-10-26 21:38:20.393856
48	a4b1e11dabad48109bd928d3ea8f04190b8bee7106cdef5ed6acd1db7770c4e7	team46	Wallet of team: team46	1000.00	2015-10-26 21:38:20.393856
49	5cb480eeb6402083ac4ce2a819cd0322130745133a9bff9af553c31cb7a961f7	team47	Wallet of team: team47	1000.00	2015-10-26 21:38:20.393856
50	755369b0f7eb13721d28c7fdaecd90c3a9cce9cc2194b5edb87872b52a3941dd	team48	Wallet of team: team48	1000.00	2015-10-26 21:38:20.393856
51	b3652ee7221a5e947044903e304fcb0f00938d2fd574389c9319fc8309d97442	team49	Wallet of team: team49	1000.00	2015-10-26 21:38:20.393856
52	506efcab5a3328c4c3c609b28a2091d2c351bf279b7f163c8a4579f5c0e9678c	team50	Wallet of team: team50	1000.00	2015-10-26 21:38:20.393856
53	e8d6f8a6495abdf3220cb85beb4cd9210be62e3c32889d4056fd60d6c7a87a4d	team51	Wallet of team: team51	1000.00	2015-10-26 21:38:20.393856
54	8a5d46ac3ba8272f7c061d31ac2a8738ce3507e6f2e83d0be5e1133db388e926	team52	Wallet of team: team52	1000.00	2015-10-26 21:38:20.393856
55	c6e60be65d420f68d0768db5c1e81b631501433447be66b81eb9f8f1595c9460	team53	Wallet of team: team53	1000.00	2015-10-26 21:38:20.393856
56	ae72a8232e8fa4bd3fe3ae07006811b078d31ee41dcba361181195de00cbb5fb	team54	Wallet of team: team54	1000.00	2015-10-26 21:38:20.393856
57	fc827d742c36d0224e6a183e507324869cfd146e3c0d29d144d5b7384b80354a	team55	Wallet of team: team55	1000.00	2015-10-26 21:38:20.393856
58	f8c26d1d19265fb5b73a4d2381fc815d6a178f819b1d073cd5b71a18d4b0924c	Team HF Crew	Wallet of team: Team HF Crew	1000.00	2015-10-26 21:38:20.393856
59	46afc7b4e1334d1ed3953039baf2bf851507df39ea51ca9c37ddc34ab9e48c7a	Team Dube	Wallet of team: Team Dube	1000.00	2015-10-26 21:38:20.393856
60	1fe2f9b018aad58e704ce172ee32b0900764773f4b7561b8c6f1fc1ca119459b	Team HF DMZ	Wallet of team: Team HF DMZ	1000.00	2015-10-26 21:38:20.393856
61	5d52c4e7406fbffc83d943a29744ff51c469920f7d16125f044d5f8579d5b01e	Team VPN	Wallet of team: Team VPN	1000.00	2015-10-26 21:38:20.393856
62	cd3b7b3e615b50faceebe81c0c4da670fec1bbb33828169adad1f84344b72cc4	Team VPN Dube	Wallet of team: Team VPN Dube	1000.00	2015-10-26 21:38:20.393856
63	847516542772a7b735312b65a328df025d661739530900a4db56a0c01e7ab197	Team VPN Pie	Wallet of team: Team VPN Pie	1000.00	2015-10-26 21:38:20.393856
1	2c9980b372721e5339ac59adb1827b36e518b76dbae87d208da7e8a798bbd242	HF Bank	Default wallet used for cash flags, money laundering, etc.	938000.00	2015-10-26 21:38:19.853207
64	55bd0f6bcd272d2167de1e2758aab60e15a2fbb42b40933d30e55382d38cc5e2	Team Eko	Wallet of team: Team Eko	1000.00	2015-10-26 21:38:20.393856
\.


--
-- Data for Name: bmitem; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY bmitem (id, name, category, statuscode, review, ownerwallet, amount, qty, displayinterval, description, importname, privateid, data, dllink, updatecmd, ts) FROM stdin;
1	ssh backdoor	1	1	\N	1	50000.00	\N	\N	the backdoor ssh user on loto hf web server	91e02cd2b8621d0c05197f645668c5c4.txt	c3bd9f9fb7ed1d7c59a28b75ade07e4efa23e5f13141a8845f85b87102198547	\N	https://scoreboard.hf/blackmarket/c3bd9f9fb7ed1d7c59a28b75ade07e4efa23e5f13141a8845f85b87102198547		2015-10-26 21:38:21.345151
2	LotoHF Network Diagram	1	1	\N	1	20000.00	\N	\N	LotoHF Network diagram with all	5b55e088f1c532ef55b12218d395f663.pdf	c3df2034f1f0eb4205e6ec0ce7c9b2608a559bef0bd00bb52217d3cadb6b41b6	\N	https://scoreboard.hf/blackmarket/c3df2034f1f0eb4205e6ec0ce7c9b2608a559bef0bd00bb52217d3cadb6b41b6		2015-10-26 21:38:21.345151
3	Leaked "be a qualified customer" requests of demat	1	1	\N	1	25000.00	\N	\N	We've hack demat !!! Get the latest requests for being a qualified customer.	demat.tar	c5867d7d46b8edfc401adebf1072b050f297126fcbbb9fba0cf632deff02c5af	\N	https://scoreboard.hf/blackmarket/c5867d7d46b8edfc401adebf1072b050f297126fcbbb9fba0cf632deff02c5af	ssh -p 2200 172.28.19.30 /home/scoreboard/getFiles && scp -P 2200 172.28.19.30:/home/scoreboard/file.tar ./blackmarket/demat.tar	2015-10-26 21:38:21.345151
4	Phenix	1	1	\N	1	25000.00	\N	\N	A windows old trick.	phenix1.txt	589b805f6175b3634fdb084086ec592c649fde8dce4038f513d17c4d46c171d2	\N	https://scoreboard.hf/blackmarket/589b805f6175b3634fdb084086ec592c649fde8dce4038f513d17c4d46c171d2		2015-10-26 21:38:21.345151
\.


--
-- Name: bmitem_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('bmitem_id_seq', 4, true);


--
-- Name: bmitemcategory_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('bmitemcategory_id_seq', 2, true);


--
-- Name: bmitemreview_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('bmitemreview_id_seq', 1, false);


--
-- Data for Name: bmitemstatus_history; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY bmitemstatus_history (id, bmitemid, statuscode, ts) FROM stdin;
1	1	6	2015-10-26 21:38:21.345151
2	1	1	2015-10-26 21:38:21.345151
3	2	6	2015-10-26 21:38:21.345151
4	2	1	2015-10-26 21:38:21.345151
5	3	6	2015-10-26 21:38:21.345151
6	3	1	2015-10-26 21:38:21.345151
7	4	6	2015-10-26 21:38:21.345151
8	4	1	2015-10-26 21:38:21.345151
\.


--
-- Name: bmitemstatus_history_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('bmitemstatus_history_id_seq', 8, true);


--
-- Name: bmitemstatus_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('bmitemstatus_id_seq', 6, true);


--
-- Data for Name: eventfacility; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY eventfacility (id, code, name, displayname, description, ts) FROM stdin;
1	0	global	Global		2015-10-26 21:38:19.853207
2	1	flag	Flag Submissions		2015-10-26 21:38:19.853207
3	2	news	News		2015-10-26 21:38:19.853207
4	3	team	Teams		2015-10-26 21:38:19.853207
5	4	bm	Black Market		2015-10-26 21:38:19.853207
6	5	loto	Loto HF		2015-10-26 21:38:19.853207
7	6	cash	Cash related		2015-10-26 21:38:19.853207
\.


--
-- Data for Name: eventseverity; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY eventseverity (id, code, name, displayname, description, ts) FROM stdin;
1	0	emerg	Emergency	System is unusable	2015-10-26 21:38:19.853207
2	1	alert	Alert	Should be corrected immediately	2015-10-26 21:38:19.853207
3	2	crit	Critical	Critical conditions	2015-10-26 21:38:19.853207
4	3	err	Error	Error conditions	2015-10-26 21:38:19.853207
5	4	warning	Warning	May indicate that an error will occur if action is not taken.	2015-10-26 21:38:19.853207
6	5	notice	Notice	Events that are unusual, but not error conditions.	2015-10-26 21:38:19.853207
7	6	info	Informational	Normal operational messages that require no action.	2015-10-26 21:38:19.853207
8	7	debug	Debug	Information useful to developers for debugging the application.	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: event; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY event (id, title, facility, severity, ts) FROM stdin;
\.


--
-- Name: event_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('event_id_seq', 1, false);


--
-- Name: eventfacility_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('eventfacility_id_seq', 7, true);


--
-- Name: eventseverity_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('eventseverity_id_seq', 8, true);


--
-- Data for Name: flagauthor; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY flagauthor (id, name, nick, ts) FROM stdin;
1	Martin Dube	mdube	2015-10-26 21:38:19.853207
2	Jessy Campos	_eko	2015-10-26 21:38:19.853207
3	Cedrick Chaput	chaput	2015-10-26 21:38:19.853207
4	Stephane Sigmen	sigmen	2015-10-26 21:38:19.853207
5	Jean-Sebastien Grenon	js	2015-10-26 21:38:19.853207
6	François Lajeunesse-Robert	flr	2015-10-26 21:38:19.853207
7	Franck Desert	hiddenman	2015-10-26 21:38:19.853207
8	Guillaume Parent	gp	2015-10-26 21:38:19.853207
9	Patrick Mathieu	patoff	2015-10-26 21:38:19.853207
10	HF Crew	HFCrew	2015-10-26 21:38:19.853207
11	Scoreboard	Scoreboard	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: flagcategory; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY flagcategory (id, name, displayname, description, hidden, ts) FROM stdin;
1	demat	Dematerialized	Build weapons of mass destructions (WMD) and then try to use them from the inside against the enemy. Attackers can build as many WMD as they want. WMD will be dropped one at the time in the order they are produced. WMD are dropped at a rate of 1 per 30 seconds. EACH AND EVERY WMD WILL BE EFFECTIVE FOR AT LEAST 30 SECONDS i.e.: If your team drop 100 ineffective WMD before an effective one, you will have to wait for 50 minutes before your effective WMD get dropped.\n\n<h3>How to see the result of your WMD:</h3>\n\nFor some of the flag listed below, you will need to make a call to the ""getFlag"" JavaScript function take will be loaded automatically in your page context. A call to this function will succeed if you were able to achieve what it is listed in the flag description. Upon success a cookie named flag will be defined in the page context containing the flag value.\n<p/>\n<em>***Warning***:</em> <ul>\n<li>To prevent brute force, if a call to ""getFlag"" fails, the current WMD will be countered. The next submitted WMD will be dropped within the next 30 seconds.</li> \n<li>For performance issues, dynamic creation of DOM elements have been disabled</li>\n</ul>	f	2015-10-26 21:38:19.853207
2	misc	Misc	Miscelaneous (Teaser on hackfest website)	f	2015-10-26 21:38:19.853207
3	hydrohf	hydroHF	Hydro HF provide electricity for mini Hackfest city.  As Hacker, you have just learned that Hydro HF Datacenter provides power to the SSRC. Shutdown the power at HydroHF you will be able to stop the power of the SSRC DataCenter and and be able to stop global surveillance. Are you ready for this contract ?You have managed to gain access to the room of the switch, and you have to find communication and look what inside network. You got information that allow you to unlock the door to the server room. This is mostly a physical and network track. Come near the model.	f	2015-10-26 21:38:19.853207
4	lotohf	Loto Hackfest	LotoHF is the biggest gaming platforme ! You need to hack as far as you can. Only the web page is visible. Will you reach the DC ?  You'll have to do the flag in order	f	2015-10-26 21:38:19.853207
5	phenix	Phenix	phenix. Use ./player.py secrets	f	2015-10-26 21:38:19.853207
6	pipeline	Pipeline	Pipeline Corp is full patched Windows environment. <br/>Full patched doesn't mean not pwnable !!!!<br/> Start your DC hunting and gather as much credentials and flag as you can.<br/><br/>You will have great power so don't mess with server configurations or we will ban your team. Hint - to be sure you won't help other teams, create your own credentials if you need it.	f	2015-10-26 21:38:19.853207
7	elcaro	Elcaro		f	2015-10-26 21:38:19.853207
8	nssa	NSSA	New Super Security Agency. It looks like these guys infected implants in several systems. All challenges are on the model.	f	2015-10-26 21:38:19.853207
9	bug	Bug Bounty	Bug Bounty Policy. Flags given for teams who raise security issues in the infrastructure. These are one timers.	f	2015-10-26 21:38:19.853207
10	thirdparty	Third Party	LockPick, babyfoot, surprise 	t	2015-10-26 21:38:19.853207
11	bonus	Bonus	Bonus Flags are used for non-standard flag types. For example, to give a bonus when a track is completed, a bonus flag is created and assigned to the team	t	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: flagstatus; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY flagstatus (id, code, name, description, ts) FROM stdin;
1	1	Enabled	The flag is functionnal	2015-10-26 21:38:19.853207
2	2	Erronous	The flag is corrupted or fucked up	2015-10-26 21:38:19.853207
3	3	Disabled	The flag is removed by admins	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: flagtype; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY flagtype (id, code, name, ts) FROM stdin;
1	1	Standard	2015-10-26 21:38:19.853207
2	2	Unique	2015-10-26 21:38:19.853207
3	11	King	2015-10-26 21:38:19.853207
4	12	Dynamic	2015-10-26 21:38:19.853207
5	13	Bonus	2015-10-26 21:38:19.853207
6	21	Group Dynamic	2015-10-26 21:38:19.853207
7	22	Group Bonus	2015-10-26 21:38:19.853207
8	31	Team Group Dynamic	2015-10-26 21:38:19.853207
9	32	Team Group Pokemon	2015-10-26 21:38:19.853207
10	41	Trap	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: flagtypeext; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY flagtypeext (id, name, typeid, pts, ptslimit, ptsstep, trapcmd, updatecmd, flagids, ts) FROM stdin;
\.


--
-- Data for Name: host; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY host (id, name, os, description, ts) FROM stdin;
1	scoreboard.hf	OpenBSD5.5 x64	Scoreboard	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: flag; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY flag (id, name, value, pts, cash, host, category, statuscode, author, type, typeext, displayinterval, description, news, ts) FROM stdin;
1	csa1	Hs17K6LakjDeTeLlwoQ5gVGP	100	0.00	1	1	1	6	2	\N	\N	<h3>Call Home -</h3> Call home as fast as you can. The first team will get a free flag. Others better luck next time.	This_is_an_automated_news$team	2015-10-26 21:38:20.246337
2	csa2	0AB2C8DZzO7W0zo0WdRrS6mv	150	0.00	1	1	1	6	1	\N	\N	<h3>Scan the\nnetwork -</h3> Look for reachable services.  Each identified service will give you points.<p/>\n\nTo retrieve a flag associate with a service, call the "getFlag" function with the URI parameter set to the URI describing the service. i.e.: &lt;scheme&gt;://&lt;hostname&gt;:&lt;port&gt;		2015-10-26 21:38:20.246337
3	csa3	U2PHFyGFxWcV3vbRGnrv5B4H	200	0.00	1	1	1	6	1	\N	\N	<h3>Scan the\nnetwork -</h3> Look for reachable services.  Each identified service will give you points.<p/>\n\nTo retrieve a flag associate with a service, call the "getFlag" function with the URI parameter set to the URI describing the service. i.e.: &lt;scheme&gt;://&lt;hostname&gt;:&lt;port&gt;		2015-10-26 21:38:20.246337
4	csa4	E9N2ocEZ21ZaCDfYWNu4EZGO	150	0.00	1	1	1	6	1	\N	\N	<h3>Scan the\nnetwork -</h3> Look for reachable services.  Each identified service will give you points.<p/>\n\nTo retrieve a flag associate with a service, call the "getFlag" function with the URI parameter set to the URI describing the service. i.e.: &lt;scheme&gt;://&lt;hostname&gt;:&lt;port&gt;		2015-10-26 21:38:20.246337
5	csa5	VvGZEg6GQmvYVx6yEWTW0Jvc	200	0.00	1	1	1	6	1	\N	\N	<h3>Scan the\nnetwork -</h3> Look for reachable services.  Each identified service will give you points.<p/>\n\nTo retrieve a flag associate with a service, call the "getFlag" function with the URI parameter set to the URI describing the service. i.e.: &lt;scheme&gt;://&lt;hostname&gt;:&lt;port&gt;		2015-10-26 21:38:20.246337
6	csa6	KxSIVhHctS3MpuGdff5QNQcH	300	0.00	1	1	1	6	1	\N	\N	<h3>Mini level up 1 -</h3> For one of the identified service, a common Web application is running. Identified it!<p/>\n\nTo retrieve a flag associate with a service, call the "getFlag" with the URI parameter set to the URI describing the service and the application. i.e.: &lt;scheme&gt;://&lt;hostname&gt;:&lt;port&gt;/&lt;application_path&gt;		2015-10-26 21:38:20.246337
7	csa7	Db9Xu4yGytwQUR3QKDgE3CFF	500	0.00	1	1	1	6	1	\N	\N	<h3>Mini level up 2 -</h3> A common vulnerability has been added to an existing feature of the Web application. Find it!\n\nThe flag is somewhere in the source code of the vulnerable page.		2015-10-26 21:38:20.246337
8	csa8	gDk99jmKRsRIRWlIDwKJY4NC	400	0.00	1	1	1	6	2	\N	\N	<h3>Mini level up 3 -</h3> Try to log in the Web application.<p/>\n\nTo retrieve a flag associate with a service, call the "getFlag" function with the URI parameter set to the URI used to log into the application i.e.: &lt;scheme&gt;://&lt;hostname&gt;:&lt;port&gt;/&lt;path&gt;		2015-10-26 21:38:20.246337
9	csa9	3UvDr8lpgeEFpXxZZclTLfUX	400	0.00	1	1	1	6	1	\N	\N	<h3>Mini level up 4 -</h3> Look inside the Web application for valuable information.\n		2015-10-26 21:38:20.246337
10	teaser1	4cabe23a7711f52c09bbbe28800a2d6a	0	100.00	1	2	1	3	1	\N	12:00:00	Teaser01		2015-10-26 21:38:20.246337
11	teaser2	bq4TALp8TvAXuOPZ6FInZA==	100	100.00	1	2	1	7	1	\N	12:00:00	Teaser02		2015-10-26 21:38:20.246337
12	teaser3	Gratz!SeeYouInNovember	100	100.00	1	2	1	2	1	\N	12:00:00	Teaser03		2015-10-26 21:38:20.246337
13	instruction1	447addca18a1e9099e8dac715e1136b6	0	100.00	1	10	1	3	1	\N	12:00:00	Read the instruction 		2015-10-26 21:38:20.246337
14	babyfoot1	77e7cddf7f28a57459778b9e5718c109	0	1000.00	1	10	1	9	1	\N	12:00:00	babyfoot01		2015-10-26 21:38:20.246337
15	hydrohf1	X8J5drognjMhjTzw4gAxZGIuSPBD1qke	100	1000.00	1	3	1	5	1	\N	\N	You had access to the switch Hydro_HF_Core_01 and Hydro_HF_Core_02. There are probably communications between computer, try to discover how to shutdown the power. Come near the model.		2015-10-26 21:38:20.246337
16	hydrohf2	dj8pvnRJuEFL5VVHyOVPFffS6hVpLG7C	100	1000.00	1	3	1	5	1	\N	\N	You had acces to the switch Hydro_HF_Dam_01 and Hydro_HF_Dam_02, you have to find the host that listening. Come near the model.		2015-10-26 21:38:20.246337
17	hydrohf3	WNmQS80CMQfdoRd75ObXAPUNl2Sq3c	100	1000.00	1	3	1	5	1	\N	\N	Attention, you have find the door, can you open to come inside the server room ? Come near the model.		2015-10-26 21:38:20.246337
18	hydrohf4	4731bc7fb04a10fb387c79a82412c70e	400	1000.00	1	3	1	5	1	\N	\N	\nYour goal is near, you have found the information about certain employees, you must now shutdown the Dam.		2015-10-26 21:38:20.246337
19	phenix1	VvnxkP4ZmWOHwNKHBMHNUJJGnMCFKWQg	100	100.00	1	5	1	7	1	\N	\N			2015-10-26 21:38:20.246337
20	phenix2	gF9vPgej3edVmIFiear4ksm8ovypgT01	300	100.00	1	5	1	7	1	\N	\N			2015-10-26 21:38:20.246337
21	phenix3	4HP8AKHjUPWSgQMhaayboFU3k6pCo6fr	300	100.00	1	5	1	7	1	\N	\N			2015-10-26 21:38:20.246337
22	phenix4	e9b3f00ab0207776cd2dd3e00f272c26	300	100.00	1	5	1	7	1	\N	\N			2015-10-26 21:38:20.246337
23	phenix5	vWxIvh7X8X4QbHK1Ql293QxvxMFcwbFE	400	100.00	1	5	1	7	1	\N	\N			2015-10-26 21:38:20.246337
24	phenix6	PQjhWo3FbS7wmxcAUiO4MMbcJlj0RTuj	500	100.00	1	5	1	7	1	\N	\N			2015-10-26 21:38:20.246337
25	lotohf1	0dbcadc23ba311d1698382eba06dec1e	100	0.00	1	4	1	3	1	\N	\N	Try to have a shell on the web server <a html="lotohf.ctf.hf"> lotohf.ctf.hf</a> 		2015-10-26 21:38:20.246337
26	lotohf2	95dcfb02bbb2630c13402d61ad002d69	100	0.00	1	4	1	3	1	\N	\N	Try to pivot in lan subnet. 		2015-10-26 21:38:20.246337
27	lotohf3	6235401daa92365013116dac3eddc38e	100	0.00	1	4	1	3	1	\N	\N	Try have a Domain User access		2015-10-26 21:38:20.246337
28	lotohf4	c41da8273f46eab41694111de52b4a39	100	0.00	1	4	1	3	1	\N	\N	Try to get the ms-sql user account password 		2015-10-26 21:38:20.246337
29	lotohf5	93181fa8565af6e79b6208778b90a3c7	100	0.00	1	4	1	3	1	\N	\N	Try to get domain admin access		2015-10-26 21:38:20.246337
30	nssa1	d5b3a9bcaa0539509cf45cdca959ef4e	100	100.00	1	8	1	1	1	\N	\N	Hack the Model!		2015-10-26 21:38:20.246337
31	nssa2	b1a6ceb4bc344c80fb697d559f320047	200	200.00	1	8	1	1	1	\N	\N	Hack the Model!		2015-10-26 21:38:20.246337
32	nssa3	d06f1adb6acbc9b955f47c0398947a91	300	300.00	1	8	1	1	1	\N	\N	Hack the Model!		2015-10-26 21:38:20.246337
33	nssa4	74290bbf62a177509f728a81f0c16cb4	400	400.00	1	8	1	1	1	\N	\N	Hack the Model!		2015-10-26 21:38:20.246337
34	re1	whatever34345345345	200	100.00	1	7	1	2	1	\N	\N			2015-10-26 21:38:20.246337
35	re2	dfif8f98utf8fj	200	200.00	1	7	1	2	1	\N	\N			2015-10-26 21:38:20.246337
36	re3	whateverdin3n3njf	300	300.00	1	7	1	2	1	\N	\N			2015-10-26 21:38:20.246337
37	re4	ff61acc62c312edd2211739f9927268c	400	400.00	1	7	1	2	1	\N	\N			2015-10-26 21:38:20.246337
38	lock1	098bbc25fd30692492bd33986078e826	0	2000.00	1	2	1	10	1	\N	24:00:00			2015-10-26 21:38:20.246337
39	lock2	d21c4c7507d792b50e356ec348adaff0	0	2000.00	1	2	1	10	1	\N	24:00:00			2015-10-26 21:38:20.246337
40	lock3	whatever123egregergerg	0	2000.00	1	2	1	10	1	\N	24:00:00			2015-10-26 21:38:20.246337
41	pipe01	FLAGoTd6mkNfT0qdQZH5xMZK	100	0.00	1	6	1	4	1	\N	\N	pipe01		2015-10-26 21:38:20.246337
42	pipe02	FLAGQ3RBc95fYPFXuFxPX2Qs	100	0.00	1	6	1	4	1	\N	\N	pipe02		2015-10-26 21:38:20.246337
43	pipe03	USERhashisflag1	100	0.00	1	6	1	4	1	\N	\N	pipe03		2015-10-26 21:38:20.246337
44	pipe04	FLAG0FJWTgLyLZCUvyHA11pk	100	0.00	1	6	1	4	1	\N	\N	pipe04		2015-10-26 21:38:20.246337
45	pipe05	USERhashisflag2	100	0.00	1	6	1	4	1	\N	\N	pipe05		2015-10-26 21:38:20.246337
46	pipe06	FLAGYSByxqVZ00KsKSljIEoH	100	0.00	1	6	1	4	1	\N	\N	pipe06		2015-10-26 21:38:20.246337
47	pipe07	USERhashisflag3	100	0.00	1	6	1	4	1	\N	\N	pipe07		2015-10-26 21:38:20.246337
48	pipe08	FLAGu6HYwtkpnReVfWeHrBse	100	0.00	1	6	1	4	1	\N	\N	pipe08		2015-10-26 21:38:20.246337
49	pipe09	USERhashisflag	100	0.00	1	6	1	4	1	\N	\N	pipe09		2015-10-26 21:38:20.246337
50	pipe10	FLAGH1iq8NEN7n4OoWFLMzse	100	0.00	1	6	1	4	1	\N	\N	pipe10		2015-10-26 21:38:20.246337
51	pipe11	FLAGyhF0jjCjlz6zMVa5JzVg	100	0.00	1	6	1	4	1	\N	\N	pipe11		2015-10-26 21:38:20.246337
52	fm1	whateverf49gf9jj49j3f9jfj4f	0	10000.00	1	10	1	8	1	\N	\N	FM01		2015-10-26 21:38:20.246337
53	cash01	e933abdc3d6a7b12cbc4c4f7bf035d38	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
54	cash02	51ca03dbfb98810c8d5fbe63c1ef04e4	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
55	cash03	646bc3da08eeec46d8e592b1e3434be2	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
56	cash04	ea847f9a7eeb7e45a9f6bdf7abf2f984	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
57	cash05	d7987c318242d9ad84d26b4b883bbaba	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
58	cash06	6786e4b0e52a02fa43f30d18d416d6f6	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
59	cash07	aa4a116609c90ef483aaf07be59a6ff6	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
60	cash08	81e3f44c6e9024cc18acf5aedcf55aaf	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
61	cash09	249edba0590c41d0d19e684eee1b6cb7	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
62	cash10	16cb6dc8b19520e59c94d3e37e373edf	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
63	cash11	8e7ee81b711f92746a5e6642f2693e46	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
64	cash12	3b3e0b2394509f418d7edaeb20e2e9ee	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
65	cash13	f697164603aab7636b6386427c4484b5	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
66	cash14	471b676d57a6251b48fc6337d826cbd7	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
67	cash15	cbedb58759421557e51000230ccb9f47	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
68	cash16	f246af282bd62dc010b5fa05bd8308cf	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
69	cash17	2dfd1302355efc9c40796cb971f69860	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
70	cash18	4a7e7d10c8865a94702704ac426950bd	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
71	cash19	bd7fc09a3a52a43fb69c7086a87484b5	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
72	cash20	a96ac74db2326634f36c4704d3b614de	0	5000.00	1	10	1	3	1	\N	24:00:00	argent		2015-10-26 21:38:20.246337
\.


--
-- Name: flag_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('flag_id_seq', 72, true);


--
-- Name: flagauthor_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('flagauthor_id_seq', 11, true);


--
-- Name: flagcategory_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('flagcategory_id_seq', 11, true);


--
-- Data for Name: flagstatus_history; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY flagstatus_history (id, flagid, statuscode, ts) FROM stdin;
\.


--
-- Name: flagstatus_history_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('flagstatus_history_id_seq', 1, false);


--
-- Name: flagstatus_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('flagstatus_id_seq', 3, true);


--
-- Name: flagtype_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('flagtype_id_seq', 10, true);


--
-- Name: flagtypeext_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('flagtypeext_id_seq', 1, false);


--
-- Name: host_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('host_id_seq', 1, true);


--
-- Data for Name: kingflag; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY kingflag (id, flagid, value, pts, ts) FROM stdin;
\.


--
-- Name: kingflag_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('kingflag_id_seq', 1, false);


--
-- Data for Name: news; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY news (id, title, displayts, ts) FROM stdin;
1	Welcome to Hackfest CTF 2015 !	2015-10-26 21:38:19.853207	2015-10-26 21:38:19.853207
\.


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('news_id_seq', 1, true);


--
-- Data for Name: team; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY team (id, name, net, wallet, hide, ts) FROM stdin;
1	_TMIH_	172.28.101.0/24	3	f	2015-10-26 21:38:20.393856
2	return ENEEDGIN;	172.28.102.0/24	4	f	2015-10-26 21:38:20.393856
3	DCIETS	172.28.103.0/24	5	f	2015-10-26 21:38:20.393856
4	Hack ULaval	172.28.104.0/24	6	f	2015-10-26 21:38:20.393856
5	Shellbleedoodleshock	172.28.105.0/24	7	f	2015-10-26 21:38:20.393856
6	Eliteroot	172.28.106.0/24	8	f	2015-10-26 21:38:20.393856
7	EMTA XIDLESYC GODS !	172.28.107.0/24	9	f	2015-10-26 21:38:20.393856
8	Flaggots	172.28.108.0/24	10	f	2015-10-26 21:38:20.393856
9	GLO in the dark	172.28.109.0/24	11	f	2015-10-26 21:38:20.393856
10	Good Work IOIextreme	172.28.110.0/24	12	f	2015-10-26 21:38:20.393856
11	crackmayorsecurity	172.28.111.0/24	13	f	2015-10-26 21:38:20.393856
12	In the middle man 	172.28.112.0/24	14	f	2015-10-26 21:38:20.393856
13	l33tb33s	172.28.113.0/24	15	f	2015-10-26 21:38:20.393856
14	Packet Drop	172.28.114.0/24	16	f	2015-10-26 21:38:20.393856
15	Ping Master	172.28.115.0/24	17	f	2015-10-26 21:38:20.393856
16	PolyHack	172.28.116.0/24	18	f	2015-10-26 21:38:20.393856
17	Quick Overflow 	172.28.117.0/24	19	f	2015-10-26 21:38:20.393856
18	Relentless Penguin Uprising	172.28.118.0/24	20	f	2015-10-26 21:38:20.393856
19	@dminPr0tect n friends	172.28.119.0/24	21	f	2015-10-26 21:38:20.393856
20	Sea and Tea	172.28.120.0/24	22	f	2015-10-26 21:38:20.393856
21	Shell investigator	172.28.121.0/24	23	f	2015-10-26 21:38:20.393856
22	BonziBuddy	172.28.122.0/24	24	f	2015-10-26 21:38:20.393856
23	thinker^or^die	172.28.123.0/24	25	f	2015-10-26 21:38:20.393856
24	Unicorn as a service	172.28.124.0/24	26	f	2015-10-26 21:38:20.393856
25	Freethinker1	172.28.125.0/24	27	f	2015-10-26 21:38:20.393856
26	Freethinker2	172.28.126.0/24	28	f	2015-10-26 21:38:20.393856
27	usedoils	172.28.127.0/24	29	f	2015-10-26 21:38:20.393856
28	team28	172.28.128.0/24	30	f	2015-10-26 21:38:20.393856
29	team29	172.28.129.0/24	31	f	2015-10-26 21:38:20.393856
30	team30	172.28.130.0/24	32	f	2015-10-26 21:38:20.393856
31	team31	172.28.131.0/24	33	f	2015-10-26 21:38:20.393856
32	team32	172.28.132.0/24	34	f	2015-10-26 21:38:20.393856
33	team33	172.28.133.0/24	35	f	2015-10-26 21:38:20.393856
34	team34	172.28.134.0/24	36	f	2015-10-26 21:38:20.393856
35	team35	172.28.135.0/24	37	f	2015-10-26 21:38:20.393856
36	team36	172.28.136.0/24	38	f	2015-10-26 21:38:20.393856
37	team37	172.28.137.0/24	39	f	2015-10-26 21:38:20.393856
38	team38	172.28.138.0/24	40	f	2015-10-26 21:38:20.393856
39	team39	172.28.139.0/24	41	f	2015-10-26 21:38:20.393856
40	team40	172.28.140.0/24	42	f	2015-10-26 21:38:20.393856
41	team41	172.28.141.0/24	43	f	2015-10-26 21:38:20.393856
42	team42	172.28.142.0/24	44	f	2015-10-26 21:38:20.393856
43	team43	172.28.143.0/24	45	f	2015-10-26 21:38:20.393856
44	team44	172.28.144.0/24	46	f	2015-10-26 21:38:20.393856
45	team45	172.28.145.0/24	47	f	2015-10-26 21:38:20.393856
46	team46	172.28.146.0/24	48	f	2015-10-26 21:38:20.393856
47	team47	172.28.147.0/24	49	f	2015-10-26 21:38:20.393856
48	team48	172.28.148.0/24	50	f	2015-10-26 21:38:20.393856
49	team49	172.28.149.0/24	51	f	2015-10-26 21:38:20.393856
50	team50	172.28.150.0/24	52	f	2015-10-26 21:38:20.393856
51	team51	172.28.151.0/24	53	f	2015-10-26 21:38:20.393856
52	team52	172.28.152.0/24	54	f	2015-10-26 21:38:20.393856
53	team53	172.28.153.0/24	55	f	2015-10-26 21:38:20.393856
54	team54	172.28.154.0/24	56	f	2015-10-26 21:38:20.393856
55	team55	172.28.155.0/24	57	f	2015-10-26 21:38:20.393856
56	Team HF Crew	172.16.66.0/24	58	f	2015-10-26 21:38:20.393856
57	Team Dube	192.168.1.0/24	59	f	2015-10-26 21:38:20.393856
58	Team HF DMZ	192.168.6.0/24	60	f	2015-10-26 21:38:20.393856
59	Team VPN	192.168.9.0/24	61	f	2015-10-26 21:38:20.393856
60	Team VPN Dube	192.168.10.0/24	62	f	2015-10-26 21:38:20.393856
61	Team VPN Pie	192.168.13.0/24	63	f	2015-10-26 21:38:20.393856
62	Team Eko	127.0.0.1/8	64	f	2015-10-26 21:38:20.393856
\.


--
-- Data for Name: player; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY player (id, teamid, nick, ip, ts) FROM stdin;
\.


--
-- Name: player_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('player_id_seq', 1, false);


--
-- Data for Name: settings; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY settings (id, gamestartts, gameendts, teamstartmoney, ts) FROM stdin;
1	2015-05-30 18:30:00	2015-05-31 02:00:00	1000.00	2015-10-26 21:38:19.853207
\.


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('settings_id_seq', 1, true);


--
-- Data for Name: submit_history; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY submit_history (id, teamid, playerip, value, ts) FROM stdin;
\.


--
-- Name: submit_history_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('submit_history_id_seq', 1, false);


--
-- Data for Name: team_bmitem; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY team_bmitem (id, teamid, bmitemid, playerip, ts) FROM stdin;
\.


--
-- Name: team_bmitem_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('team_bmitem_id_seq', 1, false);


--
-- Data for Name: team_flag; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY team_flag (id, teamid, flagid, pts, playerip, ts) FROM stdin;
\.


--
-- Name: team_flag_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('team_flag_id_seq', 1, false);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('team_id_seq', 62, true);


--
-- Data for Name: team_kingflag; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY team_kingflag (id, teamid, kingflagid, playerip, ts) FROM stdin;
\.


--
-- Name: team_kingflag_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('team_kingflag_id_seq', 1, false);


--
-- Data for Name: teamsecrets; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY teamsecrets (id, teamid, name, value, ts) FROM stdin;
1	1	PHOENIX_USER	user1	2015-10-26 21:38:20.393856
2	1	PHOENIX_PASS	pass1	2015-10-26 21:38:20.393856
3	1	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
4	1	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
5	2	PHOENIX_USER	user2	2015-10-26 21:38:20.393856
6	2	PHOENIX_PASS	pass2	2015-10-26 21:38:20.393856
7	2	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
8	2	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
9	3	PHOENIX_USER	user3	2015-10-26 21:38:20.393856
10	3	PHOENIX_PASS	pass3	2015-10-26 21:38:20.393856
11	3	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
12	3	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
13	4	PHOENIX_USER	user4	2015-10-26 21:38:20.393856
14	4	PHOENIX_PASS	pass4	2015-10-26 21:38:20.393856
15	4	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
16	4	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
17	5	PHOENIX_USER	user5	2015-10-26 21:38:20.393856
18	5	PHOENIX_PASS	pass5	2015-10-26 21:38:20.393856
19	5	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
20	5	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
21	6	PHOENIX_USER	user6	2015-10-26 21:38:20.393856
22	6	PHOENIX_PASS	pass6	2015-10-26 21:38:20.393856
23	6	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
24	6	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
25	7	PHOENIX_USER	user7	2015-10-26 21:38:20.393856
26	7	PHOENIX_PASS	pass7	2015-10-26 21:38:20.393856
27	7	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
28	7	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
29	8	PHOENIX_USER	user8	2015-10-26 21:38:20.393856
30	8	PHOENIX_PASS	pass8	2015-10-26 21:38:20.393856
31	8	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
32	8	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
33	9	PHOENIX_USER	user9	2015-10-26 21:38:20.393856
34	9	PHOENIX_PASS	pass9	2015-10-26 21:38:20.393856
35	9	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
36	9	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
37	10	PHOENIX_USER	user10	2015-10-26 21:38:20.393856
38	10	PHOENIX_PASS	pass10	2015-10-26 21:38:20.393856
39	10	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
40	10	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
41	11	PHOENIX_USER	user11	2015-10-26 21:38:20.393856
42	11	PHOENIX_PASS	pass11	2015-10-26 21:38:20.393856
43	11	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
44	11	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
45	12	PHOENIX_USER	user12	2015-10-26 21:38:20.393856
46	12	PHOENIX_PASS	pass12	2015-10-26 21:38:20.393856
47	12	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
48	12	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
49	13	PHOENIX_USER	user13	2015-10-26 21:38:20.393856
50	13	PHOENIX_PASS	pass13	2015-10-26 21:38:20.393856
51	13	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
52	13	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
53	14	PHOENIX_USER	user14	2015-10-26 21:38:20.393856
54	14	PHOENIX_PASS	pass14	2015-10-26 21:38:20.393856
55	14	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
56	14	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
57	15	PHOENIX_USER	user15	2015-10-26 21:38:20.393856
58	15	PHOENIX_PASS	pass15	2015-10-26 21:38:20.393856
59	15	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
60	15	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
61	16	PHOENIX_USER	user16	2015-10-26 21:38:20.393856
62	16	PHOENIX_PASS	pass16	2015-10-26 21:38:20.393856
63	16	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
64	16	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
65	17	PHOENIX_USER	user17	2015-10-26 21:38:20.393856
66	17	PHOENIX_PASS	pass17	2015-10-26 21:38:20.393856
67	17	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
68	17	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
69	18	PHOENIX_USER	user18	2015-10-26 21:38:20.393856
70	18	PHOENIX_PASS	pass18	2015-10-26 21:38:20.393856
71	18	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
72	18	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
73	19	PHOENIX_USER	user19	2015-10-26 21:38:20.393856
74	19	PHOENIX_PASS	pass19	2015-10-26 21:38:20.393856
75	19	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
76	19	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
77	20	PHOENIX_USER	user20	2015-10-26 21:38:20.393856
78	20	PHOENIX_PASS	pass20	2015-10-26 21:38:20.393856
79	20	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
80	20	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
81	21	PHOENIX_USER	user21	2015-10-26 21:38:20.393856
82	21	PHOENIX_PASS	pass21	2015-10-26 21:38:20.393856
83	21	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
84	21	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
85	22	PHOENIX_USER	user22	2015-10-26 21:38:20.393856
86	22	PHOENIX_PASS	pass22	2015-10-26 21:38:20.393856
87	22	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
88	22	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
89	23	PHOENIX_USER	user23	2015-10-26 21:38:20.393856
90	23	PHOENIX_PASS	pass23	2015-10-26 21:38:20.393856
91	23	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
92	23	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
93	24	PHOENIX_USER	user24	2015-10-26 21:38:20.393856
94	24	PHOENIX_PASS	pass24	2015-10-26 21:38:20.393856
95	24	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
96	24	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
97	25	PHOENIX_USER	user25	2015-10-26 21:38:20.393856
98	25	PHOENIX_PASS	pass25	2015-10-26 21:38:20.393856
99	25	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
100	25	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
101	26	PHOENIX_USER	user26	2015-10-26 21:38:20.393856
102	26	PHOENIX_PASS	pass26	2015-10-26 21:38:20.393856
103	26	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
104	26	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
105	27	PHOENIX_USER	user27	2015-10-26 21:38:20.393856
106	27	PHOENIX_PASS	pass27	2015-10-26 21:38:20.393856
107	27	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
108	27	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
109	28	PHOENIX_USER	user28	2015-10-26 21:38:20.393856
110	28	PHOENIX_PASS	pass28	2015-10-26 21:38:20.393856
111	28	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
112	28	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
113	29	PHOENIX_USER	user29	2015-10-26 21:38:20.393856
114	29	PHOENIX_PASS	pass29	2015-10-26 21:38:20.393856
115	29	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
116	29	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
117	30	PHOENIX_USER	user30	2015-10-26 21:38:20.393856
118	30	PHOENIX_PASS	pass30	2015-10-26 21:38:20.393856
119	30	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
120	30	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
121	31	PHOENIX_USER	user31	2015-10-26 21:38:20.393856
122	31	PHOENIX_PASS	pass31	2015-10-26 21:38:20.393856
123	31	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
124	31	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
125	32	PHOENIX_USER	user32	2015-10-26 21:38:20.393856
126	32	PHOENIX_PASS	pass32	2015-10-26 21:38:20.393856
127	32	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
128	32	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
129	33	PHOENIX_USER	user33	2015-10-26 21:38:20.393856
130	33	PHOENIX_PASS	pass33	2015-10-26 21:38:20.393856
131	33	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
132	33	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
133	34	PHOENIX_USER	user34	2015-10-26 21:38:20.393856
134	34	PHOENIX_PASS	pass34	2015-10-26 21:38:20.393856
135	34	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
136	34	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
137	35	PHOENIX_USER	user35	2015-10-26 21:38:20.393856
138	35	PHOENIX_PASS	pass35	2015-10-26 21:38:20.393856
139	35	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
140	35	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
141	36	PHOENIX_USER	user36	2015-10-26 21:38:20.393856
142	36	PHOENIX_PASS	pass36	2015-10-26 21:38:20.393856
143	36	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
144	36	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
145	37	PHOENIX_USER	user37	2015-10-26 21:38:20.393856
146	37	PHOENIX_PASS	pass37	2015-10-26 21:38:20.393856
147	37	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
148	37	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
149	38	PHOENIX_USER	user38	2015-10-26 21:38:20.393856
150	38	PHOENIX_PASS	pass38	2015-10-26 21:38:20.393856
151	38	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
152	38	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
153	39	PHOENIX_USER	user39	2015-10-26 21:38:20.393856
154	39	PHOENIX_PASS	pass39	2015-10-26 21:38:20.393856
155	39	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
156	39	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
157	40	PHOENIX_USER	user40	2015-10-26 21:38:20.393856
158	40	PHOENIX_PASS	pass40	2015-10-26 21:38:20.393856
159	40	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
160	40	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
161	41	PHOENIX_USER	user41	2015-10-26 21:38:20.393856
162	41	PHOENIX_PASS	pass41	2015-10-26 21:38:20.393856
163	41	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
164	41	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
165	42	PHOENIX_USER	user42	2015-10-26 21:38:20.393856
166	42	PHOENIX_PASS	pass42	2015-10-26 21:38:20.393856
167	42	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
168	42	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
169	43	PHOENIX_USER	user43	2015-10-26 21:38:20.393856
170	43	PHOENIX_PASS	pass43	2015-10-26 21:38:20.393856
171	43	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
172	43	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
173	44	PHOENIX_USER	user44	2015-10-26 21:38:20.393856
174	44	PHOENIX_PASS	pass44	2015-10-26 21:38:20.393856
175	44	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
176	44	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
177	45	PHOENIX_USER	user45	2015-10-26 21:38:20.393856
178	45	PHOENIX_PASS	pass45	2015-10-26 21:38:20.393856
179	45	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
180	45	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
181	46	PHOENIX_USER	user46	2015-10-26 21:38:20.393856
182	46	PHOENIX_PASS	pass46	2015-10-26 21:38:20.393856
183	46	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
184	46	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
185	47	PHOENIX_USER	user47	2015-10-26 21:38:20.393856
186	47	PHOENIX_PASS	pass47	2015-10-26 21:38:20.393856
187	47	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
188	47	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
189	48	PHOENIX_USER	user48	2015-10-26 21:38:20.393856
190	48	PHOENIX_PASS	pass48	2015-10-26 21:38:20.393856
191	48	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
192	48	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
193	49	PHOENIX_USER	user49	2015-10-26 21:38:20.393856
194	49	PHOENIX_PASS	pass49	2015-10-26 21:38:20.393856
195	49	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
196	49	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
197	50	PHOENIX_USER	user50	2015-10-26 21:38:20.393856
198	50	PHOENIX_PASS	pass50	2015-10-26 21:38:20.393856
199	50	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
200	50	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
201	51	PHOENIX_USER	user51	2015-10-26 21:38:20.393856
202	51	PHOENIX_PASS	pass51	2015-10-26 21:38:20.393856
203	51	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
204	51	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
205	52	PHOENIX_USER	user52	2015-10-26 21:38:20.393856
206	52	PHOENIX_PASS	pass52	2015-10-26 21:38:20.393856
207	52	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
208	52	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
209	53	PHOENIX_USER	user53	2015-10-26 21:38:20.393856
210	53	PHOENIX_PASS	pass53	2015-10-26 21:38:20.393856
211	53	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
212	53	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
213	54	PHOENIX_USER	user54	2015-10-26 21:38:20.393856
214	54	PHOENIX_PASS	pass54	2015-10-26 21:38:20.393856
215	54	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
216	54	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
217	55	PHOENIX_USER	user55	2015-10-26 21:38:20.393856
218	55	PHOENIX_PASS	pass55	2015-10-26 21:38:20.393856
219	55	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
220	55	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
221	56	PHOENIX_USER	user56	2015-10-26 21:38:20.393856
222	56	PHOENIX_PASS	pass56	2015-10-26 21:38:20.393856
223	56	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
224	56	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
225	57	PHOENIX_USER	user57	2015-10-26 21:38:20.393856
226	57	PHOENIX_PASS	pass57	2015-10-26 21:38:20.393856
227	57	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
228	57	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
229	58	PHOENIX_USER	user58	2015-10-26 21:38:20.393856
230	58	PHOENIX_PASS	pass58	2015-10-26 21:38:20.393856
231	58	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
232	58	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
233	59	PHOENIX_USER	user59	2015-10-26 21:38:20.393856
234	59	PHOENIX_PASS	pass59	2015-10-26 21:38:20.393856
235	59	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
236	59	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
237	60	PHOENIX_USER	user60	2015-10-26 21:38:20.393856
238	60	PHOENIX_PASS	pass60	2015-10-26 21:38:20.393856
239	60	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
240	60	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
241	61	PHOENIX_USER	user61	2015-10-26 21:38:20.393856
242	61	PHOENIX_PASS	pass61	2015-10-26 21:38:20.393856
243	61	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
244	61	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
245	62	PHOENIX_USER	user62	2015-10-26 21:38:20.393856
246	62	PHOENIX_PASS	pass62	2015-10-26 21:38:20.393856
247	62	PHOENIX_HOST	hf01.cloudblabla	2015-10-26 21:38:20.393856
248	62	PHOENIX_PORT	444	2015-10-26 21:38:20.393856
\.


--
-- Name: teamsecrets_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('teamsecrets_id_seq', 248, true);


--
-- Data for Name: transactiontype; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY transactiontype (id, code, name, description, ts) FROM stdin;
1	1	Start Wallet	Money received at the begining of the CTF	2015-10-26 21:38:19.853207
2	2	Cash Flag	Money received by submiting a cash or hybrid flag	2015-10-26 21:38:19.853207
3	3	Item bought	Money sent by buying an item on the black market	2015-10-26 21:38:19.853207
4	4	Money Laundering	Money received by laundering money with a CTF admin	2015-10-26 21:38:19.853207
5	5	Loto HF	Money won at loto HF	2015-10-26 21:38:19.853207
\.


--
-- Data for Name: transaction; Type: TABLE DATA; Schema: scoreboard; Owner: owner
--

COPY transaction (id, srcwalletid, dstwalletid, amount, type, description, ts) FROM stdin;
1	1	3	1000.00	1	\N	2015-10-26 21:38:20.393856
2	1	4	1000.00	1	\N	2015-10-26 21:38:20.393856
3	1	5	1000.00	1	\N	2015-10-26 21:38:20.393856
4	1	6	1000.00	1	\N	2015-10-26 21:38:20.393856
5	1	7	1000.00	1	\N	2015-10-26 21:38:20.393856
6	1	8	1000.00	1	\N	2015-10-26 21:38:20.393856
7	1	9	1000.00	1	\N	2015-10-26 21:38:20.393856
8	1	10	1000.00	1	\N	2015-10-26 21:38:20.393856
9	1	11	1000.00	1	\N	2015-10-26 21:38:20.393856
10	1	12	1000.00	1	\N	2015-10-26 21:38:20.393856
11	1	13	1000.00	1	\N	2015-10-26 21:38:20.393856
12	1	14	1000.00	1	\N	2015-10-26 21:38:20.393856
13	1	15	1000.00	1	\N	2015-10-26 21:38:20.393856
14	1	16	1000.00	1	\N	2015-10-26 21:38:20.393856
15	1	17	1000.00	1	\N	2015-10-26 21:38:20.393856
16	1	18	1000.00	1	\N	2015-10-26 21:38:20.393856
17	1	19	1000.00	1	\N	2015-10-26 21:38:20.393856
18	1	20	1000.00	1	\N	2015-10-26 21:38:20.393856
19	1	21	1000.00	1	\N	2015-10-26 21:38:20.393856
20	1	22	1000.00	1	\N	2015-10-26 21:38:20.393856
21	1	23	1000.00	1	\N	2015-10-26 21:38:20.393856
22	1	24	1000.00	1	\N	2015-10-26 21:38:20.393856
23	1	25	1000.00	1	\N	2015-10-26 21:38:20.393856
24	1	26	1000.00	1	\N	2015-10-26 21:38:20.393856
25	1	27	1000.00	1	\N	2015-10-26 21:38:20.393856
26	1	28	1000.00	1	\N	2015-10-26 21:38:20.393856
27	1	29	1000.00	1	\N	2015-10-26 21:38:20.393856
28	1	30	1000.00	1	\N	2015-10-26 21:38:20.393856
29	1	31	1000.00	1	\N	2015-10-26 21:38:20.393856
30	1	32	1000.00	1	\N	2015-10-26 21:38:20.393856
31	1	33	1000.00	1	\N	2015-10-26 21:38:20.393856
32	1	34	1000.00	1	\N	2015-10-26 21:38:20.393856
33	1	35	1000.00	1	\N	2015-10-26 21:38:20.393856
34	1	36	1000.00	1	\N	2015-10-26 21:38:20.393856
35	1	37	1000.00	1	\N	2015-10-26 21:38:20.393856
36	1	38	1000.00	1	\N	2015-10-26 21:38:20.393856
37	1	39	1000.00	1	\N	2015-10-26 21:38:20.393856
38	1	40	1000.00	1	\N	2015-10-26 21:38:20.393856
39	1	41	1000.00	1	\N	2015-10-26 21:38:20.393856
40	1	42	1000.00	1	\N	2015-10-26 21:38:20.393856
41	1	43	1000.00	1	\N	2015-10-26 21:38:20.393856
42	1	44	1000.00	1	\N	2015-10-26 21:38:20.393856
43	1	45	1000.00	1	\N	2015-10-26 21:38:20.393856
44	1	46	1000.00	1	\N	2015-10-26 21:38:20.393856
45	1	47	1000.00	1	\N	2015-10-26 21:38:20.393856
46	1	48	1000.00	1	\N	2015-10-26 21:38:20.393856
47	1	49	1000.00	1	\N	2015-10-26 21:38:20.393856
48	1	50	1000.00	1	\N	2015-10-26 21:38:20.393856
49	1	51	1000.00	1	\N	2015-10-26 21:38:20.393856
50	1	52	1000.00	1	\N	2015-10-26 21:38:20.393856
51	1	53	1000.00	1	\N	2015-10-26 21:38:20.393856
52	1	54	1000.00	1	\N	2015-10-26 21:38:20.393856
53	1	55	1000.00	1	\N	2015-10-26 21:38:20.393856
54	1	56	1000.00	1	\N	2015-10-26 21:38:20.393856
55	1	57	1000.00	1	\N	2015-10-26 21:38:20.393856
56	1	58	1000.00	1	\N	2015-10-26 21:38:20.393856
57	1	59	1000.00	1	\N	2015-10-26 21:38:20.393856
58	1	60	1000.00	1	\N	2015-10-26 21:38:20.393856
59	1	61	1000.00	1	\N	2015-10-26 21:38:20.393856
60	1	62	1000.00	1	\N	2015-10-26 21:38:20.393856
61	1	63	1000.00	1	\N	2015-10-26 21:38:20.393856
62	1	64	1000.00	1	\N	2015-10-26 21:38:20.393856
\.


--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('transaction_id_seq', 62, true);


--
-- Name: transactiontype_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('transactiontype_id_seq', 5, true);


--
-- Name: wallet_id_seq; Type: SEQUENCE SET; Schema: scoreboard; Owner: owner
--

SELECT pg_catalog.setval('wallet_id_seq', 64, true);


--
-- PostgreSQL database dump complete
--

